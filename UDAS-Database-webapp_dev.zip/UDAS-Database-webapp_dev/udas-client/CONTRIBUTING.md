# How to contribute?

### What kind of help you can use ?

Except the ideas for the project (wheather the features or design/implementation) 
we are in need for people with really basic understanding (at this point) of Java and OOP concepts, JavaFX GUI framework,
MySQL.

Also, we are using Maven. 

Also, remmember, all this is voluntarily and meant to help out organization of amputees.
They will have proper application to manage their membership and we will gain some experience and fun !

##  Check out issues section !

Before you start to work on any of those issues make some comment so it can be assigned to you.
That way, we can be sure only one person ise working on a issue at the time.

Take a look at the labels. Good First Issue is always good. 

##  Check out milestones !

As you can see, milestones are longer goals and guidance in which direction is our project heading.
For now, project has 3 phases:
1. CRUD + Parametrized search
2. Reports + Charts
3. User role hierarchies

Later on we will introduce Art School project within this one.

##  Take care when updating or making changes on MySQL database !

Currently we are using MySQL db (switched from MSSQL for possible portability). 
Database issues are tagged with MySQL. If you are going to make changes on DB itself
be sure to create [PATCH](https://lornajane.net/posts/2010/simple-database-patching-strategy) for it properly before making pull request.
When update-ing database, you have to use patches iteratively.

## If you do not understand something - ask !

Best idea is to communicate trough GitHub itself. If you have any questions,
open an issue with "question" label and wait for response !
I try to respond as fast as I can.

# Thank you and have fun !

