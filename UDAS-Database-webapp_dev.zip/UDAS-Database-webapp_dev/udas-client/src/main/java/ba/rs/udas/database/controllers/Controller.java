package ba.rs.udas.database.controllers;

public interface Controller {

}
