package ba.rs.udas.database.controllers.dialogs;

import ba.rs.udas.database.controllers.Controller;
import javafx.fxml.FXML;
import javafx.stage.Stage;

public final class ValuesEditorController implements Controller {
  public static void setupStage(Stage stage) {
  }

  private void setUpBindings() {
  }

  @FXML
  private void initialize() {
    setUpBindings();
  }
}
