package ba.rs.udas.database.util;

public class InputValidator {

  public static boolean validateConnectionCredentials(String username, String password) {
    //TODO validation logic
    return true;
  }
}
