package ba.rs.udas.database.model.database;

import org.junit.jupiter.api.Test;

class ConnectionManagerTest {

  @Test
  void shouldReturnConnectionOnConnect() {
  }

  @Test
  void getConnection() {
  }

  @Test
  void isConnected() {
  }

  @Test
  void close() {
  }
}